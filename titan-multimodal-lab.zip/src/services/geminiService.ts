import { GoogleGenAI } from "@google/genai";

const API_KEY = process.env.GEMINI_API_KEY || "";

export const ai = new GoogleGenAI({ apiKey: API_KEY });

// Models based on the gemini-api skill
export const MODELS = {
  FLASH: 'gemini-3-flash-preview',
  PRO: 'gemini-3.1-pro-preview',
  AUDIO: 'gemini-3.1-flash-live-preview',
  IMAGE: 'gemini-2.5-flash-image',
};

export interface MultimodalPart {
  inlineData?: {
    mimeType: string;
    data: string;
  };
  text?: string;
}

export async function generateMultimodalResponse(
  prompt: string,
  parts: MultimodalPart[] = [],
  modelName: string = MODELS.FLASH
) {
  if (!API_KEY) {
    throw new Error("GEMINI_API_KEY is not set. Please add it to your secrets.");
  }

  const contents = {
    parts: [
      ...parts,
      { text: prompt }
    ]
  };

  try {
    const response = await ai.models.generateContent({
      model: modelName,
      contents,
    });

    return response.text;
  } catch (error) {
    console.error("Gemini API Error:", error);
    throw error;
  }
}
