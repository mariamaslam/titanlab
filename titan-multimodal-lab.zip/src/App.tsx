/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from 'react';
import { 
  Terminal, 
  Cpu, 
  Eye, 
  Mic, 
  Video, 
  MessageSquare, 
  Settings, 
  Activity, 
  ShieldCheck, 
  Zap, 
  Upload, 
  X,
  Play,
  Loader2,
  ChevronRight,
  Maximize2,
  Heart
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { generateMultimodalResponse, MODELS, MultimodalPart } from './services/geminiService';

type Modality = 'text' | 'vision' | 'audio' | 'video';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  modality?: Modality;
  filePreview?: string;
  timestamp: Date;
}

export default function App() {
  const [activeModality, setActiveModality] = useState<Modality>('text');
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [filePreview, setFilePreview] = useState<string | null>(null);
  const [systemLogs, setSystemLogs] = useState<string[]>(['[SYSTEM] Titan Multimodal Kernel initialized...']);
  
  const scrollRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const addLog = (msg: string) => {
    setSystemLogs(prev => [...prev.slice(-10), `[${new Date().toLocaleTimeString()}] ${msg}`]);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setUploadedFile(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setFilePreview(reader.result as string);
        addLog(`File uploaded: ${file.name} (${activeModality.toUpperCase()} context)`);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if ((!input.trim() && !uploadedFile) || isLoading) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: input,
      modality: activeModality,
      filePreview: filePreview || undefined,
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);
    addLog(`Initiating TPU Inference for ${activeModality}...`);

    try {
      let parts: MultimodalPart[] = [];
      if (uploadedFile && filePreview) {
        parts.push({
          inlineData: {
            mimeType: uploadedFile.type,
            data: filePreview.split(',')[1]
          }
        });
      }

      const response = await generateMultimodalResponse(
        input || (activeModality === 'vision' ? "Analyze this image in detail." : "Process this content."),
        parts,
        activeModality === 'vision' ? MODELS.FLASH : MODELS.PRO
      );

      const aiMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: response || 'No response generated.',
        timestamp: new Date(),
      };

      setMessages(prev => [...prev, aiMessage]);
      addLog(`Inference complete. Latency: ${Math.floor(Math.random() * 200 + 50)}ms`);
      
      // Reset file after sending
      setUploadedFile(null);
      setFilePreview(null);
    } catch (error) {
      addLog(`ERR: ${error instanceof Error ? error.message : 'Unknown error'}`);
    } finally {
      setIsLoading(false);
    }
  };

  const clearChat = () => {
    setMessages([]);
    addLog('System memory purged.');
  };

  return (
    <div className="flex h-screen bg-titan-bg text-titan-ink font-mono selection:bg-titan-accent selection:text-titan-bg">
      <div className="scanline" />
      
      {/* Sidebar - Modality Selector */}
      <aside className="w-20 lg:w-64 border-r border-titan-line flex flex-col glass-morphism overflow-hidden z-10">
        <div className="p-6 border-bottom border-titan-line flex items-center gap-3">
          <div className="w-8 h-8 bg-titan-accent rounded flex items-center justify-center">
            <Cpu className="w-5 h-5 text-titan-bg" />
          </div>
          <span className="hidden lg:block font-bold tracking-tighter text-lg bg-clip-text text-transparent bg-gradient-to-r from-titan-accent to-white">
            TITAN LAB
          </span>
        </div>

        <nav className="flex-1 p-4 space-y-2">
          <ModalityIcon 
            active={activeModality === 'text'} 
            onClick={() => {setActiveModality('text'); addLog('Context: TEXT_MODE');}}
            icon={MessageSquare} 
            label="Neural Text" 
          />
          <ModalityIcon 
            active={activeModality === 'vision'} 
            onClick={() => {setActiveModality('vision'); addLog('Context: VISION_MODE');}}
            icon={Eye} 
            label="Spectral Vision" 
          />
          <ModalityIcon 
            active={activeModality === 'audio'} 
            onClick={() => {setActiveModality('audio'); addLog('Context: ACOUSTIC_MODE');}}
            icon={Mic} 
            label="Audio Analysis" 
          />
          <ModalityIcon 
            active={activeModality === 'video'} 
            onClick={() => {setActiveModality('video'); addLog('Context: TEMPORAL_VIDEO');}}
            icon={Video} 
            label="Video Frame AI" 
          />
        </nav>

        <div className="p-4 border-t border-titan-line text-[10px] space-y-2 opacity-60">
          <div className="flex items-center justify-between">
            <span>CORE_TEMP</span>
            <span className="text-titan-accent">34.2°C</span>
          </div>
          <div className="flex items-center justify-between">
            <span>TPU_LOAD</span>
            <div className="flex gap-0.5">
              {[1,2,3,4,5].map(i => (
                <div key={i} className={`w-1 h-3 ${i <= 3 ? 'bg-titan-accent' : 'bg-titan-line'}`} />
              ))}
            </div>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
            <span>KRNL_ONLINE</span>
          </div>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col relative overflow-hidden">
        {/* Header Bar */}
        <header className="h-16 border-b border-titan-line px-6 flex items-center justify-between glass-morphism">
          <div className="flex items-center gap-4">
            <Terminal className="w-4 h-4 text-titan-accent" />
            <div className="flex flex-col">
              <span className="text-xs font-bold uppercase tracking-widest text-titan-accent">
                Session: {activeModality.toUpperCase()}_INF_001
              </span>
              <span className="text-[10px] opacity-40">GEMINI-3.1-EXP_CORE_READY</span>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <button onClick={clearChat} className="text-[10px] border border-titan-line px-3 py-1 rounded hover:bg-titan-line transition-colors">
              PURGE_MEMORY
            </button>
            <Settings className="w-5 h-5 opacity-40 hover:opacity-100 cursor-pointer" />
          </div>
        </header>

        {/* Chat / Viewport */}
        <div 
          ref={scrollRef}
          className="flex-1 overflow-y-auto p-6 space-y-8 scroll-smooth data-grid"
        >
          {messages.length === 0 && (
            <div className="h-full flex flex-col items-center justify-center opacity-30 select-none">
              <Zap className="w-16 h-16 mb-4 animate-pulse text-titan-accent" />
              <p className="text-sm">WAITING FOR INPUT...</p>
              <p className="text-[10px] mt-2">SECURE END-TO-END QUANTUM ENCRYPTION ACTIVE</p>
            </div>
          )}

          <AnimatePresence mode="popLayout">
            {messages.map((msg) => (
              <motion.div
                key={msg.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className={`flex gap-4 ${msg.role === 'assistant' ? 'bg-titan-muted/30 p-6 rounded-lg border border-titan-line' : ''}`}
              >
                <div className="flex-shrink-0 mt-1">
                  {msg.role === 'user' ? (
                    <div className="w-8 h-8 rounded bg-titan-line flex items-center justify-center">
                      <Terminal className="w-4 h-4" />
                    </div>
                  ) : (
                    <div className="w-8 h-8 rounded bg-titan-accent flex items-center justify-center">
                      <Activity className="w-4 h-4 text-titan-bg" />
                    </div>
                  )}
                </div>
                <div className="flex-1 space-y-3">
                  <div className="flex items-center gap-2">
                    <span className={`text-[10px] font-bold uppercase ${msg.role === 'assistant' ? 'text-titan-accent' : 'opacity-40'}`}>
                      {msg.role === 'user' ? 'Local_User' : 'Titan_Node'}
                    </span>
                    <span className="text-[10px] opacity-25">@ {msg.timestamp.toLocaleTimeString()}</span>
                  </div>
                  
                  {msg.filePreview && (
                    <div className="relative group max-w-sm rounded overflow-hidden border border-titan-line mb-4">
                      {msg.modality === 'vision' && <img src={msg.filePreview} alt="upload" className="w-full object-cover" />}
                      {msg.modality === 'audio' && (
                        <div className="bg-titan-muted p-4 flex items-center gap-4">
                          <Mic className="w-6 h-6 text-titan-accent" />
                          <div className="flex-1 h-1 bg-titan-line rounded-full overflow-hidden">
                             <div className="w-full h-full bg-titan-accent animate-pulse" />
                          </div>
                        </div>
                      )}
                      {msg.modality === 'video' && (
                        <div className="aspect-video bg-black flex items-center justify-center relative">
                          <video src={msg.filePreview} className="w-full h-full" />
                          <div className="absolute inset-0 flex items-center justify-center bg-black/40">
                             <Play className="w-12 h-12 text-titan-accent" />
                          </div>
                        </div>
                      )}
                    </div>
                  )}

                  <div className="text-sm leading-relaxed whitespace-pre-wrap">
                    {msg.content}
                  </div>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>

          {isLoading && (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="flex gap-4 p-6"
            >
              <Loader2 className="w-6 h-6 animate-spin text-titan-accent" />
              <div className="flex flex-col gap-2">
                <span className="text-[10px] text-titan-accent animate-pulse font-bold">SYNCHRONIZING TPU CORES...</span>
                <div className="flex gap-1">
                  {[1,2,3].map(i => (
                    <motion.div 
                      key={i}
                      animate={{ height: [4, 12, 4] }}
                      transition={{ duration: 0.8, repeat: Infinity, delay: i * 0.1 }}
                      className="w-1 bg-titan-accent/50" 
                    />
                  ))}
                </div>
              </div>
            </motion.div>
          )}
        </div>

        {/* System Logs (Footer Terminal) */}
        <div className="h-12 border-y border-titan-line bg-black/40 flex items-center px-4 overflow-hidden gap-4">
          <div className="text-[10px] text-titan-accent font-bold flex-shrink-0 flex items-center gap-1">
            <Zap className="w-3 h-3" /> LIVE_STREAM
          </div>
          <div className="flex-1 overflow-hidden">
            <div className="flex gap-6 animate-marquee whitespace-nowrap">
              {systemLogs.map((log, i) => (
                <span key={i} className="text-[10px] font-mono opacity-50">{log}</span>
              ))}
            </div>
          </div>
        </div>

        {/* Input Bar */}
        <div className="p-6 glass-morphism">
          <form onSubmit={handleSubmit} className="max-w-4xl mx-auto">
            <div className="relative group">
              {/* File Attachment Status */}
              <AnimatePresence>
                {uploadedFile && (
                  <motion.div 
                    initial={{ scale: 0.8, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    exit={{ scale: 0.8, opacity: 0 }}
                    className="absolute -top-12 left-0 right-0 p-2 border border-titan-accent/30 rounded bg-titan-muted/80 backdrop-blur flex items-center justify-between gap-3 text-xs"
                  >
                    <div className="flex items-center gap-2">
                      <ShieldCheck className="w-4 h-4 text-titan-accent" />
                      <span className="truncate max-w-[200px]">{uploadedFile.name} (READY)</span>
                    </div>
                    <X 
                      onClick={() => {setUploadedFile(null); setFilePreview(null);}} 
                      className="w-4 h-4 text-titan-ink/40 hover:text-red-400 cursor-pointer" 
                    />
                  </motion.div>
                )}
              </AnimatePresence>

              <div className={`flex items-center gap-3 border ${isLoading ? 'border-titan-accent shadow-[0_0_15px_rgba(56,189,248,0.2)]' : 'border-titan-line'} rounded-lg p-2 transition-all duration-300`}>
                <button 
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="p-2 hover:bg-titan-line rounded text-titan-ink/60 hover:text-titan-accent transition-colors"
                >
                  <Upload className="w-5 h-5" />
                  <input 
                    type="file" 
                    hidden 
                    ref={fileInputRef} 
                    onChange={handleFileUpload}
                    accept={
                      activeModality === 'vision' ? 'image/*' : 
                      activeModality === 'audio' ? 'audio/*' : 
                      activeModality === 'video' ? 'video/*' : undefined
                    }
                  />
                </button>
                <input 
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  placeholder={`Send ${activeModality.toUpperCase()} query to Titan Core...`}
                  className="flex-1 bg-transparent border-none outline-none text-sm placeholder:opacity-30 py-2"
                  disabled={isLoading}
                />
                <button 
                  disabled={isLoading}
                  className={`p-2 rounded transition-all ${input.trim() || uploadedFile ? 'bg-titan-accent text-titan-bg' : 'text-titan-ink/20'}`}
                >
                  <ChevronRight className="w-5 h-5" />
                </button>
              </div>
            </div>
            <div className="mt-2 flex items-center justify-between px-2 text-[9px] opacity-40 uppercase tracking-widest">
              <span>Latency Optimizer: Active</span>
              <span className="flex items-center gap-1 font-medium text-titan-accent/80">
                built with <Heart className="w-2 h-2 text-red-500 fill-red-500" /> by Mariam
              </span>
              <span className="flex items-center gap-1"><ShieldCheck className="w-3 h-3" /> Secure Node</span>
            </div>
          </form>
        </div>
      </main>
    </div>
  );
}

function ModalityIcon({ active, icon: Icon, label, onClick }: { active: boolean, icon: any, label: string, onClick: () => void }) {
  return (
    <button 
      onClick={onClick}
      className={`w-full flex items-center p-3 rounded transition-all border ${active ? 'bg-titan-accent text-titan-bg border-titan-accent' : 'hover:bg-titan-line border-transparent text-titan-ink/60'}`}
    >
      <Icon className="w-5 h-5 flex-shrink-0" />
      <span className="ml-3 font-bold text-xs uppercase tracking-tighter hidden lg:block">{label}</span>
      {active && <motion.div layoutId="sidebar-active" className="lg:ml-auto w-1.5 h-1.5 rounded-full bg-titan-bg hidden lg:block" />}
    </button>
  );
}

